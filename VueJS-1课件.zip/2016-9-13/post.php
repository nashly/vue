<?php
$a=$_POST['a'];
$b=$_POST['b'];
echo $a-$b;
?>